import { Component } from '@angular/core';
import { User } from '../users.service';
import { UsersService } from '../users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  newUser: User = new User('', '', '', '', '');
password: any;

  constructor(private usersService: UsersService, private router: Router) {}

  register(): void {
    this.usersService.addUser(this.newUser);
    alert('Registered successfully!');
    this.router.navigate(['/login']);
  }
}
