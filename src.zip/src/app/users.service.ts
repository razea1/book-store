import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  private localStorageKey = 'registeredUsers';
  private currentUser: User | null = null;

  constructor() {}

  getUsers(): User[] {
    const storedUsers = localStorage.getItem(this.localStorageKey);
    return storedUsers ? JSON.parse(storedUsers) : [];
  }

  addUser(user: User): void {
    const storedUsers = localStorage.getItem(this.localStorageKey);
    let users: User[] = storedUsers ? JSON.parse(storedUsers) : [];
    users.push(user);
    localStorage.setItem(this.localStorageKey, JSON.stringify(users));
    console.log('New User Added:', user);
    console.log('All Users:', users);
  }

  login(username: string, password: string): boolean {
    const users = this.getUsers();
    // Check if there's a user with the provided username and password
    const authenticatedUser = users.find(user => user.UserName === username && user.Password === password);
    if (authenticatedUser) {
      this.currentUser = authenticatedUser; // Set the current user
      return true;
    }
    return false;
  }
  
  getCurrentUser(): User | null {
    return this.currentUser;
  }

}

export class User {
  public UserName: string;
  public Email: string;
  public Password: string;
  public Address: string;
  public ImageURL: string;

  constructor(UserName: string, Email: string, Password: string, Address: string, ImageURL: string) {
    this.UserName = UserName;
    this.Email = Email;
    this.Password = Password;
    this.Address = Address;
    this.ImageURL = ImageURL;
  }
}
